# Progress screen – individual icon assets

This pack contains 34 standalone icons/illustrations isolated from the supplied Progress screen.

- `svg/` = individual SVG files for Claude/app use
- `png/` = transparent PNG counterparts
- `manifest.json` = names, sizes, crop metadata

Important: the source mockup is raster, so each SVG is a wrapper containing the isolated artwork.
This preserves the exact visual appearance better than attempting to redraw the icons as approximate vector paths.
Dynamic values, text, and progress rings are intentionally not baked into these icons.
