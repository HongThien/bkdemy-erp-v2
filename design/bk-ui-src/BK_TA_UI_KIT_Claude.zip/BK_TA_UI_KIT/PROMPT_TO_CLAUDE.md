# Prompt gửi Claude Code

Hãy đọc `CLAUDE_START_HERE.md` trước, sau đó đọc toàn bộ thư mục `spec/` và xem các ảnh trong `references/target/`.

Nhiệm vụ: redesign UI app TA BK Academy theo đúng visual language trong bộ KIT này, đồng thời giữ nguyên business logic/API/state management/navigation hiện có trong repo. `references/original/` chỉ dùng để hiểu chức năng và dữ liệu cũ; KHÔNG dùng style cũ làm chuẩn.

Yêu cầu quan trọng:
1. Inspect codebase trước, xác định framework, router, theme, state management và các màn tương ứng.
2. Lập bảng mapping: màn hiện tại -> file hiện tại -> component mới cần tạo -> API/data đang dùng.
3. Tạo design tokens/theme dùng chung trước khi sửa hàng loạt màn hình.
4. Tạo reusable components theo `spec/components.md`, không copy-paste UI.
5. Implement từng màn theo `spec/screens.md`.
6. Home bắt buộc gộp avatar + `Chào {Tên}` + role vào hero, không để tên/avatar lặp thêm ở header.
7. Giữ giao diện thoáng, dễ đọc; game-like nhưng không rối mắt.
8. Không dùng screenshot full-screen làm UI. Ảnh reference chỉ để đối chiếu thiết kế.
9. Nếu thiếu illustration/mascot asset, dùng placeholder component có kích thước đúng và ghi rõ asset cần thay; không chặn tiến độ build UI.
10. Không thay business logic hoặc schema backend chỉ để khớp mockup.

Trước tiên hãy trả về PLAN ngắn gọn gồm:
- stack phát hiện được;
- các file sẽ sửa/tạo;
- component tree;
- thứ tự triển khai;
- rủi ro/data còn thiếu.
Sau đó triển khai luôn, không cần chờ tôi xác nhận nếu không có blocker thật sự.

Sau khi hoàn thành:
- chạy lint/typecheck/build/test khả dụng;
- liệt kê file đã thay đổi;
- nêu phần nào khớp reference, phần nào dùng placeholder;
- không tự ý redesign sang style khác.
