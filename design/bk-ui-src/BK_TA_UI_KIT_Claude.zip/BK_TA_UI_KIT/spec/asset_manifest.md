# Asset Manifest & Rules

## Target references
Tất cả ảnh trong `references/target/` là visual specification, không phải asset để render nguyên màn hình.

## Asset cần có trong implementation
- avatar thật của user: dùng nguồn hiện tại của app.
- mascot BK: nên là PNG/WebP transparent hoặc SVG nếu có bản vector.
- functional icons: ưu tiên icon library/vector hiện có trong repo; giữ stroke/size nhất quán.
- reward illustrations: WebP/PNG transparent.
- decorative blobs/stars: nên làm bằng CSS/native shapes/vector để nhẹ.

## Nếu chưa có mascot asset
Tạo component `BKAssistantMascot` với placeholder tạm thời và đúng bounding box theo mockup. Để comment/TODO rõ ràng để thay asset, không dùng screenshot crop có dính chữ/nền làm asset production.

## Quy tắc hình ảnh
- Không bitmap hóa text vào ảnh.
- Không dùng full-screen PNG thay cho layout thật.
- Illustration không được chặn tap target hoặc text.
- Có `pointerEvents: none`/equivalent cho decoration nếu cần.
- Dùng WebP/AVIF cho bitmap khi platform hỗ trợ.
