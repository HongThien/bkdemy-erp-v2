# Screen Specifications

## 1. Home — `a_clean_modern_mobile_app_ui_mockup_in_a_playful.png`
Target chính.

### Structure
1. Safe status area.
2. `GreetingHero`:
   - avatar nằm ngay cạnh `Chào Thùy 👋`;
   - role `BK Trợ giảng` ngay dưới;
   - status: `Không còn việc — nghỉ ngơi thôi!`;
   - mascot phía phải;
   - bell/settings nhỏ ở góc trên nếu app có.
3. `DateCard`: ngày hiện tại + `Xem lịch`.
4. Quick actions dạng grid/card, theo chức năng app hiện có.
5. `Công việc hôm nay`.
6. Empty state nếu không có task.
7. Motivation strip.
8. Bottom nav.

### Không làm
- Không có profile row riêng phía trên hero.
- Không lặp `Thùy` hai lần.
- Không để mascot chiếm quá nhiều diện tích.

---

## 2. Điểm danh — `bk_academy_attendance_schedule.png`
Data-heavy, tối giản hơn Home.

### Structure
- Title `ĐIỂM DANH BUỔI HỌC`.
- Green `DateNavigator` gồm prev / date / next và summary `đã mở / chưa mở`.
- Section `ĐÃ MỞ` và `CHƯA MỞ`.
- `SessionRow`:
  - time badge trái;
  - class + subject;
  - end time + room;
  - trạng thái hoặc `Mở buổi` button bên phải.
- Bottom nav fixed.

### Priority
Class name, time, room và CTA phải scan được trong <1 giây.

---

## 3. Report & Báo tan — tham khảo collage target
- Blue hero/header.
- Segmented tabs: `Chưa gửi`, `Đã gửi`, `Đã duyệt`.
- Empty state lớn nhưng gọn nếu không có item.
- Khi có data: list row theo cùng design language, không dùng illustration trên từng dòng.

---

## 4. Chuẩn bị phòng / Prep — tham khảo collage target
- Yellow/orange header.
- Tabs: `Chưa làm`, `Đã hoàn thành`, `Tất cả`.
- Empty state broom/clean room.
- Khi có job: room, thời gian, checklist/status, CTA.

---

## 5. Test đầu vào — tham khảo collage target
- Purple header.
- Tabs: `Chưa chạy`, `Đang chạy`, `Đã xong`.
- Empty state clean.
- Running items cần timer/status nổi bật.

---

## 6. Bài trên lớp — `bk_academy_classwork_dashboard.png`
- Blue hero/header với title `Bài trên lớp · sạch nợ ✓`.
- Mascot nhỏ bên phải header, không chen dữ liệu.
- Completion/empty banner.
- `Đã xong (N)`.
- List rows compact: green check + class + date + chevron.
- Không cần card quá cao.

---

## 7. Chấm ET — `chấm_et_sạch_nợ_hoàn_thành_hôm_nay.png`
- Purple hero/header.
- Same skeleton as Bài trên lớp.
- Giữ list compact và visual state bằng check green.
- Nội dung `Buổi bù` vẫn hiển thị như một row bình thường.

---

## 8. Chấm BTVN — `bk_academy_homework_check_screen.png`
- Mint/teal hero/header.
- Same skeleton as Bài trên lớp/ET.
- Dùng shared component, chỉ đổi accent color + icon + copy.

---

## 9. Quà / Reward — tham khảo collage target
- Orange/yellow theme.
- Header có tổng điểm tích lũy và history.
- Category tabs.
- Product grid 2–3 cột tùy width, card pastel.
- Mỗi item: illustration, tên, giá điểm.
- Không nhồi mô tả dài.

---

## 10. Của Tôi — `giao_diện_của_tôi_bk_academy.png`
Đây là hub cá nhân.

### Top summary
- profile/avatar/name;
- `Điểm tích lũy` luôn thấy;
- `% hoàn thành task` chỉ là một ô nhỏ, chỉ cần phần trăm rõ ràng.

### 6 feature boxes
- Xếp hạng
- Gậy
- May mắn
- Tiến trình
- Shopping
- Hướng dẫn

Card 2 cột, pastel khác nhau, icon illustration rõ. Không thêm nhiều copy phụ.

---

## 11. Xếp hạng — `bảng_xếp_hạng_bk_academy_pastel.png`
- Hai tab tương ứng 2 bảng xếp hạng hiện có.
- Top 3 dùng podium/avatars.
- User hiện tại highlight trong list.
- Điểm tích lũy + completion % có thể xuất hiện ở summary bar trên cùng.

---

## 12. Gậy — `giao_diện_bk_academy_gậy_tháng_này.png`
- Summary tháng: tổng số gậy.
- Filter tuần / tháng / tất cả nếu dữ liệu hỗ trợ.
- Mỗi strike card phải có:
  - loại vi phạm;
  - ngày;
  - lớp/context;
  - số gậy;
  - **lý do bị đánh** hiển thị trực tiếp, không bắt user mở detail mới biết.
- Tone không quá punitive; vẫn rõ trạng thái.

---

## 13. May mắn — `vòng_quay_may_mắn_cùng_bk.png`
- 1 lượt/ngày/người.
- Wheel là focus chính.
- CTA `Quay ngay`.
- Hiển thị xác suất thưởng minh bạch phía dưới.
- Animation: rotate easing + deceleration + result celebration; kết quả phải do backend/secure RNG quyết định trước animation, không lấy kết quả từ góc quay client.

---

## 14. Tiến trình — `giao_diện_tiến_trình_học_viện_pastel_đáng_yêu.png`
- Top: tổng tiến trình tháng = average/aggregate từ các lớp phụ trách.
- Mỗi lớp = 1 card lớn.
- Trong class card có 4 KPI mini cards:
  1. Trợ giảng buổi
  2. Chấm BTVN
  3. Chấm ET
  4. Bổ trợ
- Hiển thị `actual / target`, ring/progress ngắn gọn, và trạng thái `Đạt chuẩn / Thiếu N`.
- Có month selector.
- Đây là màn cơ sở tính lương nên số liệu phải ưu tiên hơn decoration.

---

## 15. Shopping — `mua_sắm_đổi_quà_bk_pastel.png`
- Header: điểm tích lũy + streak hiện tại.
- Rule summary có thể collapse/expand.
- Categories.
- Grid item: Trà sữa, Kem, Tokbokki, snack... + giá điểm + CTA đổi quà.
- Disable CTA nếu thiếu điểm và show số điểm còn thiếu.
- Có favorite nếu business cần, không bắt buộc.

---

## 16. Hướng dẫn — `giao_diện_hướng_dẫn_bk_academy_kawaii.png`
- Search.
- Mỗi quy trình = 1 card.
- Click card -> detail/bottom sheet/full screen document.
- UI ban đầu có thể dùng placeholder data; nội dung quy trình sẽ bổ sung sau.
- Categories nên data-driven để sau này mở rộng.
