# Component System

## Foundation
- `BKScreen`: safe area + background + optional scroll + bottom nav inset.
- `BKTopBar`: back/title/action; dùng cho màn con.
- `BKBottomNav`: icon + label + active pill/soft background.
- `BKCard`: surface trắng, radius 18–24, shadow nhẹ.
- `BKSectionTitle`: title + optional count/action.
- `BKStatusPill`: success/warning/neutral/danger.
- `BKEmptyState`: icon/illustration + title + subtitle.
- `BKListRow`: leading status/icon, title, subtitle/date, trailing action/chevron.
- `BKSegmentedTabs`: tab compact, active rõ nhưng không quá chói.

## Home
- `GreetingHero`
  - avatar
  - greeting
  - role
  - daily status pill
  - small mascot/decorative art
  - optional bell/settings actions
- `DateCard`
- `QuickActionGrid`
- `TodayWorkCard`
- `MotivationStrip`

## Operational screens
- `DateNavigator`
- `SessionRow`
- `TaskHistoryRow`
- `OpenSessionButton`
- `CompletionBanner`

## Của tôi
- `ProfileSummaryCard`
- `MiniMetricCard`
- `FeatureTile`
- `RankingPodium`
- `StrikeCard`
- `LuckyWheel`
- `ProgressSummary`
- `ClassProgressCard`
- `KpiMiniCard`
- `ShopItemCard`
- `GuideCard`

## Rules
- Không mỗi màn tự tạo một kiểu card khác nhau nếu cùng chức năng.
- Icon box thường 44–56px, pastel background.
- Card data-heavy không dùng illustration lớn.
- Trailing chevron nhỏ, secondary color.
- Primary CTA màu solid/gradient nhẹ, label bold.
