# Navigation Notes

Bộ ảnh có nhiều nhóm chức năng từ UI hiện tại. Claude phải **giữ navigation thật của repo làm nguồn sự thật**, sau đó áp style mới.

Hai pattern nhìn thấy trong source/reference:

### Operational bottom nav
`Hôm nay / Điểm danh / Report / Prep / Test / Quà / Của tôi`

### TA grading bottom nav
`Hôm nay / Bài trên lớp / Chấm ET / Chấm BTVN / Bổ trợ / Của tôi`

Không tự gộp 2 pattern thành một nav 12 item. Nếu codebase có role-based nav, giữ role-based nav. Nếu chỉ có một role TA, dùng chính cấu hình nav hiện tại của repo.

Active item:
- icon + label accent;
- soft rounded background/pill sau icon;
- inactive = blue-grey.
