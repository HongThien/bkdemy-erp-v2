# Business Rules

## Tiến trình TA theo tháng
Theo từng lớp TA phụ trách:
- Lớp 2 buổi/tuần: `Trợ giảng = 8 buổi/tháng`.
- Lớp 1 buổi/tuần: `Trợ giảng = 4 buổi/tháng`.
- `Chấm BTVN = 7 lần/tháng`.
- `Chấm ET = 7 lần/tháng`.
- `Bổ trợ = 8 giờ/tháng`.

Nguồn dữ liệu:
- Trợ giảng / BTVN / ET: lấy trực tiếp từ dữ liệu buổi học hoặc nguồn hiện có tương ứng.
- Bổ trợ: lấy từ dữ liệu bổ trợ.

Màn Tiến trình phải cho TA nhìn thấy ngay còn thiếu/thừa bao nhiêu trên từng lớp. Đây cũng là dữ liệu nền để tính lương.

## Điểm tích lũy / streak
Mỗi ngày hoàn thành `100% task`:
- ngày thứ 1 liên tục: +1 điểm;
- ngày thứ 2 liên tục: +2 điểm;
- ngày thứ 3 liên tục: +3 điểm;
- ... tiếp tục theo streak.

Nếu có 1 ngày không đạt 100% task:
- streak hiện tại reset về 0;
- **điểm tích lũy đã kiếm được không bị mất**.

Cuối tháng:
- chốt điểm tháng và lưu lịch sử;
- tháng mới streak tính lại từ đầu;
- số điểm tích lũy đã lưu không reset.

Điểm tích lũy phải hiện trên đầu màn `Của Tôi` và `Shopping`.

## May mắn
Mỗi nhân sự: tối đa 1 lượt/ngày.

Reward probabilities:
- 10.000đ: 5%
- 20.000đ: 1%
- 50.000đ: 0.1%
- không trúng: 93.9%

Tổng = 100%.

Yêu cầu kỹ thuật:
- server authoritative nếu app có backend;
- một request/idempotency key cho mỗi lượt quay để tránh double claim;
- lưu timestamp, user, result, reward;
- UI animation chỉ reveal kết quả đã được quyết định, không tự quyết định reward.

## Gậy
Mỗi record tối thiểu:
- type/title;
- reason;
- date/time;
- class/context nếu có;
- count/severity nếu business sử dụng;
- optional evidence/detail.

## Hướng dẫn
Mỗi quy trình tối thiểu:
- id;
- title;
- short description;
- category;
- icon/cover;
- content source/file/url;
- updatedAt;
- version nếu có.
