# BK TA UI KIT — Claude Handoff

Bộ handoff để Claude Code build giao diện app BK TA theo style đã chốt.

## Bắt đầu
1. Giải nén KIT vào repo hoặc attach toàn bộ folder cho Claude.
2. Gửi nội dung `PROMPT_TO_CLAUDE.md`.
3. Bảo Claude đọc `CLAUDE_START_HERE.md` trước.

## Folder
- `references/target`: visual target.
- `references/original`: screenshot UI cũ để hiểu logic/data.
- `spec`: tokens, components, screens, business rules, navigation.

## Quyết định thiết kế quan trọng nhất
Home không còn profile header lặp lại. Avatar nằm trong hero `Chào Thùy`, cùng role và trạng thái hôm nay.

## Chú ý
Ảnh AI reference có thể có một vài chữ/minor detail không hoàn hảo; khi xung đột, ưu tiên business rules + nội dung thật trong app, còn ảnh dùng làm chuẩn bố cục và style.
