# BK Academy — TA Mobile UI Kit

## Mục tiêu
Build lại UI app TA theo đúng visual language trong `references/target/`, nhưng giữ nguyên business logic, API, state management và dữ liệu hiện có của codebase.

**Ưu tiên theo thứ tự:**
1. Dễ đọc, thao tác nhanh trên mobile.
2. Giống target reference về bố cục, bo góc, typography, khoảng trắng, gradient, trạng thái active.
3. Vui, trẻ, hơi game-like nhưng không rối mắt.
4. Không hy sinh usability để lấy trang trí.

## Cách dùng bộ KIT
- `references/target/`: nguồn chuẩn về visual. Đây là đích thiết kế.
- `references/original/`: nguồn tham khảo về dữ liệu, flow, chức năng và nội dung cũ. Không copy style cũ.
- `spec/design_tokens.json`: token giao diện chung.
- `spec/components.md`: component cần tái sử dụng.
- `spec/screens.md`: đặc tả từng màn.
- `spec/business_rules.md`: business logic quan trọng.
- `spec/asset_manifest.md`: quy tắc asset/illustration.
- `PROMPT_TO_CLAUDE.md`: prompt có thể copy nguyên văn cho Claude Code.

## Nguyên tắc triển khai bắt buộc
- Trước khi sửa code, inspect repo để xác định framework, router, state management, theme system và API layer hiện tại.
- Không rewrite architecture nếu không cần thiết.
- Không dùng screenshot nguyên màn hình làm background/UI.
- Tách UI thành reusable components và data-driven sections.
- Không hard-code dữ liệu demo nếu repo đã có data thật.
- Dữ liệu backend/API không đổi chỉ vì redesign UI.
- Giữ safe-area, keyboard avoidance, loading/error/empty states.
- Các list dài phải scroll mượt và dùng virtualization nếu framework hỗ trợ.
- Tất cả tap target tối thiểu khoảng 44x44 pt.
- Typography phải ưu tiên readability, không dùng chữ viết tay cho nội dung chính.

## Visual direction
Phong cách: **BK Friendly Game UI**
- nền rất sáng, hơi xanh/trắng;
- card trắng, bo lớn, shadow rất nhẹ;
- màu chủ đạo rõ theo từng chức năng;
- icon/illustration dễ thương nhưng dùng có tiết chế;
- mascot chỉ nên xuất hiện ở banner/empty-state, không xuất hiện trong mọi card;
- text chính navy đậm, text phụ xanh xám;
- khoảng trắng rộng, không nhồi thông tin.

## Quy tắc Home đã chốt
**Không hiển thị tên người dùng hai lần.**
Avatar + `Chào Thùy 👋` + role nằm chung trong hero greeting card. Không có thêm một profile header riêng phía trên.

Hero có:
- avatar bên trái;
- `Chào {firstName} 👋`;
- role nhỏ bên dưới;
- trạng thái hôm nay dạng pill;
- mascot/illustration ở mép phải;
- notification/settings có thể nằm góc trên của hero/safe header, nhưng không lặp lại tên/avatar.

## Mức độ trang trí
- Home / Của tôi / Quà / May mắn: có thể game hóa nhiều hơn.
- Điểm danh / Report / Prep / Test / Bài trên lớp / Chấm ET / Chấm BTVN: ưu tiên data density + scan nhanh, trang trí ít hơn.
- Không dùng quá 1 mascot lớn trên một màn hình.
- Không quá 1 gradient hero lớn trên một màn hình data-heavy.

## Definition of Done
Một màn được coi là xong khi:
- visually gần target reference;
- không phá data flow hiện tại;
- có loading/empty/error state;
- responsive trên màn iPhone nhỏ và lớn;
- text không bị truncate vô lý;
- bottom nav không nhảy layout;
- component dùng token thay vì magic numbers tràn lan;
- build/lint/typecheck pass.
