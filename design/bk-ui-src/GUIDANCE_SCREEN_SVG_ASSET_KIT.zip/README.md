# Guidance Screen SVG Asset Kit

45 individual assets extracted from the Guidance screen.
Each asset is included as SVG + transparent PNG.
SVG files embed the exact PNG artwork to preserve visual fidelity for Claude/app implementation.
