PROGRESS SCREEN SVG ASSETS

This pack contains isolated full icons from the progress screen.
Each asset includes a transparent PNG and a matching SVG wrapper.
Because the source is a raster mockup, these are not original vector paths;
they are isolated full-icon assets prepared for Claude/UI rebuilding.
