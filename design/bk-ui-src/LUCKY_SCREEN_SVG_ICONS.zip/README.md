# Lucky Screen SVG Icons

Each asset is provided as:
- individual transparent PNG
- matching SVG wrapper embedding the exact PNG asset

This keeps the icon/illustration visually closest to the original screen.
